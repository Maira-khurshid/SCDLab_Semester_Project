/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Doc;
import Model.User;
/**
 *
 * @author DELL
 */
public class UserDoc {
    public static void save(User user){
     String query = "insert into user(name,email,Mobile_Number,address,Password,ConfirmPassword) values(" + user.getName()+ "','" + user.getEmail()+"','"+user.getContact_no()+"',"+ user.getAddress()+"','"+user.getPassword()+"','"+user.getConfirm_Password()+")";
     DbOperations.setDataOrDelete(query, "Registered Successfully! Wait for the Admin Approval!");
    }
    
}
