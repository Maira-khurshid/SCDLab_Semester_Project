/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author DELL
 */
public class BillDao {
    public static  ArrayList<Bill> getAllRecordsByInc(String date) {
         ArrayList<Bill> arrayList = new ArrayList<>();
         try{
             ReasultSet rs = DbOperations.getData("select * from bill where date like '%"+date+"%'");
             while(rs.next()){
             Bill bill = new Bill();
             bill.setId(rs.getInt("id"));
             bill.setName(rs.getString("name"));
             bill.setMobileNumber(rs.getString("mobilenumber"));
             bill.setEmail(rs.getString("email"));
             bill.setDate(rs.getString("date"));
             bill.setTotal(rs.getString("total"));
             bill.setCreatedBy(rs.getString("createdBy"));
             arrayList.add(bill);
             }
             
             
         }
         catch (Exception e) {
             JOptionPane.showMessageDialog(null, e);
         }
         return arrayList;
    }
    
     public static  ArrayList<Bill> getAllRecordsByDesc(String date) {
         ArrayList<Bill> arrayList = new ArrayList<>();
         try{
             ReasultSet rs = DbOperations.getData("select * from bill where date like '%"+date+"%' order By id DESC");
             while(rs.next()){
             Bill bill = new Bill();
             bill.setId(rs.getInt("id"));
             bill.setName(rs.getString("name"));
             bill.setMobileNumber(rs.getString("mobilenumber"));
             bill.setEmail(rs.getString("email"));
             bill.setDate(rs.getString("date"));
             bill.setTotal(rs.getString("total"));
             bill.setCreatedBy(rs.getString("createdBy"));
             arrayList.add(bill);
             }
             
             
         }
         catch (Exception e) {
             JOptionPane.showMessageDialog(null, e);
         }
         return arrayList;
    }
}
