/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author DELL
 */
public class ManageCategoryTest {
    
    public ManageCategoryTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void testValidateField() {
//        System.out.println("validateField");
//        ManageCategory instance = new ManageCategory();
//        instance.validateField();
//        fail("The test case is a prototype.");
    }

    @Test
    public void testAddcat() {
//        System.out.println("addcat");
//        String categorya = "";
//        ManageCategory instance = new ManageCategory();
//        boolean expResult = false;
//        boolean result = instance.addcat(categorya);
//        assertEquals(expResult, result);
//        fail("The test case is a prototype.");
    }

    @Test
    public void testMain() {
         System.out.println("addcat");
        String categorya = "Fast food";
        ManageCategory instance = new ManageCategory();
        boolean expResult = true;
        boolean result = instance.addcat(categorya);
        assertEquals(expResult, result);
        
    }
    
}
